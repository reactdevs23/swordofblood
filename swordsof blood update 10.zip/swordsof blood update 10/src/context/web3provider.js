import React from 'react';
const Web3Provider = React.createContext(null);
export default Web3Provider;