import React from 'react';
import Banner from '../homepage/banner';
import Guide from './guide';

export default function Presale() {
	return (
		<>
		<Banner/>
		<Guide/>
		</>
	)
}