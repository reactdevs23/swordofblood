import React from 'react';
const Localization = React.createContext(null);
export default Localization;